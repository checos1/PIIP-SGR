﻿namespace DNP.Backbone.Web.API.Test.WebApi
{
    using System.Collections.Generic;
    using System.Web.Http.Results;
    using Controllers;
    using Dominio.Dto;
    using Microsoft.Practices.Unity;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Servicios.Interfaces;

    [TestClass]
    public class ProyectosControllerTest
    {
        private IBackboneServicios _backboneServicios;
        private ProyectosController _proyectosController;

        [TestInitialize]
        public void Init()
        {
            _backboneServicios = Config.UnityConfig.Container.Resolve<IBackboneServicios>();
            _proyectosController = new ProyectosController(_backboneServicios);
        }

        [TestMethod]
        public void CuandoEnvioUsuario_NoRetornaResultado()
        {
            var responsable = "xxxxxxx";

            var actionResult = _proyectosController.ObtenerProyectoPorResponsable(responsable).Result;
            var proyectosPorResponsable = ((OkNegotiatedContentResult<List<SectorDto>>)actionResult).Content;

            Assert.IsTrue(proyectosPorResponsable.Count == 0);
        }

        [TestMethod]
        public void CuandoEnvioUsuario_RetornaResultado()
        {
            var responsable = "jdelgado";

            var actionResult = _proyectosController.ObtenerProyectoPorResponsable(responsable).Result;
            var proyectosPorResponsable = ((OkNegotiatedContentResult<List<SectorDto>>)actionResult).Content;

            Assert.IsTrue(proyectosPorResponsable.Count > 0);
        }

    }
}
