﻿using DNP.Backbone.Persistencia.Implementaciones;
using DNP.Backbone.Persistencia.Interfaces;
using DNP.Backbone.Servicios.Implementaciones;
using DNP.Backbone.Servicios.Interfaces;
using DNP.Backbone.Web.API.Controllers;
using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Http.Results;
using DNP.Backbone.Dominio.Dto;
using System.Collections.Generic;

namespace DNP.Backbone.Test.WebAPI
{
    using Mocks;

    [TestClass]
    public class BackboneMockControllerTest
    {
        #region Objetos

        private IBackboneServiciosMock _backboneServiciosMock;

        #endregion

        #region Inicializacion

        [TestInitialize]
        public void Init()
        {
            ConfigurarContenedor();
            _backboneServiciosMock = ConfigurarContenedor().Resolve<IBackboneServiciosMock>();
        }

        private UnityContainer ConfigurarContenedor()
        {
            var container = new UnityContainer();
            container.RegisterType<IProyectoPersistencia, ProyectoPersistenciaMock>();
            container.RegisterType<IBackboneServiciosMock, BackboneServiciosMock>();
            return container;
        }

        private BackboneMockController ObtenerBackboneMockController()
        {
            return new BackboneMockController(_backboneServiciosMock);
        }
        #endregion

        #region Metodos de prueba

        [Ignore]
        [TestMethod]
        [Description("Trae los datos de un usuario valido con roles asignados a entidades y proyectos")]
        public void ObtenerProyectosEntidadesPorUsuarioRoles_UsuarioValido()
        {
            var usuarioDnp = "jdelgado";
            var registrosEsperados = 48;

            var actionResult = ObtenerBackboneMockController().ObtenerProyectosEntidadesPorUsuarioRoles(usuarioDnp).Result;
            var entidadesProyectosPorUsuario = ((OkNegotiatedContentResult<List<ProyectosEntidadesDto>>)actionResult).Content;

            Assert.IsNotNull(entidadesProyectosPorUsuario);
            Assert.IsTrue(entidadesProyectosPorUsuario.Count == registrosEsperados);
        }

        [Ignore]
        [TestMethod]
        [Description("Consulta datos para un usuario inexistente")]
        public void ObtenerProyectosEntidadesPorUsuarioRoles_UsuarioInValido()
        {
            var usuarioDnp = "jdelgados";
            var actionResult = ObtenerBackboneMockController().ObtenerProyectosEntidadesPorUsuarioRoles(usuarioDnp).Result;
            Assert.IsNotNull(actionResult);
        }

        [Ignore]
        [TestMethod]
        [Description("Trae los datos de un usuario valido con roles asignados a entidades y proyectos")]
        public void ObtenerProyectosEntidadesPorUsuarioRoles_UsuarioValidoSinRegistros()
        {
            var usuarioDnp = "jdelgado2";
            var registrosEsperados = 48;

            var actionResult = ObtenerBackboneMockController().ObtenerProyectosEntidadesPorUsuarioRoles(usuarioDnp).Result;
            var entidadesProyectosPorUsuario = ((OkNegotiatedContentResult<List<ProyectosEntidadesDto>>)actionResult).Content;

            Assert.IsNotNull(entidadesProyectosPorUsuario);
            Assert.IsTrue(entidadesProyectosPorUsuario.Count == registrosEsperados);
        }


        #endregion
    }
}
