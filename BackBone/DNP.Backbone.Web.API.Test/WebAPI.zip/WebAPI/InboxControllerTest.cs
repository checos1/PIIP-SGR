﻿namespace DNP.Backbone.Web.API.Test.WebApi
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Security.Principal;
    using System.Threading.Tasks;
    using System.Web.Http.Results;
    using Comunes.Dto;
    using Comunes.Excepciones;
    using Comunes.Properties;
    using Controllers;
    using Dominio.Dto.Inbox;
    using Microsoft.Practices.Unity;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Servicios.Interfaces.Autorizacion;
    using Servicios.Interfaces.Inbox;

    [TestClass]
    public class InboxControllerTest
    {
        private IInboxServicios _inboxServicios;
        private IAutorizacionServicios _autorizacionServicios;
        private InboxController _inboxController;

        [TestInitialize]
        public void Init()
        {
            _inboxServicios = Config.UnityConfig.Container.Resolve<IInboxServicios>();
            _autorizacionServicios = Config.UnityConfig.Container.Resolve<IAutorizacionServicios>();
            _inboxController = new InboxController(_inboxServicios, _autorizacionServicios);
            _inboxController.ControllerContext.Request = new HttpRequestMessage();
            _inboxController.ControllerContext.Request.Headers.Authorization = new AuthenticationHeaderValue("Basic", "Z3VlY2hldmVycnlAZG5wLmdvdi5jbzoxMjM0");
            _inboxController.ControllerContext.Request.Headers.Add("piip-idAplicacion", "AP:Backbone");
            _inboxController.User = new GenericPrincipal(new GenericIdentity("jdelgado", "Qwer1234"), new[] { "" });
        }

        [TestMethod]
        public async Task ObtenerInbox_ParametrosNull()
        {
            try
            {
                await _inboxController.ObtenerInbox(null);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.NoContent, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametrosNoRecibidos), e.Response.ReasonPhrase);
            }
            
        }

        [TestMethod]
        public async Task ObtenerInbox_AplicacionNull()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                     Aplicacion = null,
                                     IdUsuario = "jdelgado",
                                     IdObjeto = new Guid("bc154cba-50a5-4209-81ce-7c0ff0aec2ce"),
                                     ListaIdsRoles =
                                         new List<Guid>()
                                         {
                                             Guid.
                                                 Parse("4fe0a3de-0b14-45ed-9137-248bd206a418"),
                                             Guid.
                                                 Parse("d76678e3-9264-4663-afe9-7bce43828024"),
                                             Guid.
                                                 Parse("1dd225f4-5c34-4c55-b11d-e5856a68839b")
                                         }
                                 };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "Aplicacion"), e.Response.ReasonPhrase);
            }

        }

        [TestMethod]
        public async Task ObtenerInbox_AplicacionEspacioVacio()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                     Aplicacion = " ",
                                     IdUsuario = "jdelgado",
                                     IdObjeto = new Guid("bc154cba-50a5-4209-81ce-7c0ff0aec2ce"),
                                     ListaIdsRoles =
                                         new List<Guid>()
                                         {
                                             Guid.
                                                 Parse("4fe0a3de-0b14-45ed-9137-248bd206a418"),
                                             Guid.
                                                 Parse("d76678e3-9264-4663-afe9-7bce43828024"),
                                             Guid.
                                                 Parse("1dd225f4-5c34-4c55-b11d-e5856a68839b")
                                         }
                                 };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "Aplicacion"), e.Response.ReasonPhrase);
            }
        }

        [TestMethod]
        public async Task ObtenerInbox_IdUsuarioNull()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                    Aplicacion = "AP:Backbone",
                                     IdUsuario = null,
                                     IdObjeto = new Guid("bc154cba-50a5-4209-81ce-7c0ff0aec2ce"),
                                     ListaIdsRoles =
                                         new List<Guid>()
                                         {
                                             Guid.
                                                 Parse("4fe0a3de-0b14-45ed-9137-248bd206a418"),
                                             Guid.
                                                 Parse("d76678e3-9264-4663-afe9-7bce43828024"),
                                             Guid.
                                                 Parse("1dd225f4-5c34-4c55-b11d-e5856a68839b")
                                         }
                                 };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "IdUsuario"), e.Response.ReasonPhrase);
            }
        }

        [TestMethod]
        public async Task ObtenerInbox_IdUsuarioEspacioVacio()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                     Aplicacion = "AP:Backbone",
                                     IdUsuario = " ",
                                     IdObjeto = new Guid("bc154cba-50a5-4209-81ce-7c0ff0aec2ce"),
                                     ListaIdsRoles =
                                         new List<Guid>()
                                         {
                                             Guid.
                                                 Parse("4fe0a3de-0b14-45ed-9137-248bd206a418"),
                                             Guid.
                                                 Parse("d76678e3-9264-4663-afe9-7bce43828024"),
                                             Guid.
                                                 Parse("1dd225f4-5c34-4c55-b11d-e5856a68839b")
                                         }
                                 };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "IdUsuario"), e.Response.ReasonPhrase);
            }
        }

        [TestMethod]
        public async Task ObtenerInbox_IObjetoNull()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                     Aplicacion = "AP:Backbone",
                                     IdUsuario = "jdelgado",
                                     ListaIdsRoles =
                                         new List<Guid>()
                                         {
                                             Guid.
                                                 Parse("4fe0a3de-0b14-45ed-9137-248bd206a418"),
                                             Guid.
                                                 Parse("d76678e3-9264-4663-afe9-7bce43828024"),
                                             Guid.
                                                 Parse("1dd225f4-5c34-4c55-b11d-e5856a68839b")
                                         }
                                 };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "IdObjeto"), e.Response.ReasonPhrase);
            }
        }

        [TestMethod]
        public async Task ObtenerInbox_ListaIdsRolesNull()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                     Aplicacion = "AP:Backbone",
                                     IdUsuario = "jdelgado",
                                       IdObjeto = Guid.NewGuid()
                };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "ListaIdsRoles"), e.Response.ReasonPhrase);
            }
        }

        [TestMethod]
        public async Task ObtenerInbox_ListaIdsRolesVacio()
        {
            try
            {
                var parametros = new ParametrosInboxDto
                                 {
                                     Aplicacion = "AP:Backbone",
                                     IdUsuario = "jdelgado",
                                     IdObjeto = Guid.NewGuid(),
                                     ListaIdsRoles = new List<Guid>()
                                 };
                await _inboxController.ObtenerInbox(parametros);
            }
            catch (BackboneResponseException e)
            {
                Assert.AreEqual(HttpStatusCode.BadRequest, e.Response.StatusCode);
                Assert.AreEqual(string.Format(Resources.ParametroNoRecibido, "ListaIdsRoles"), e.Response.ReasonPhrase);
            }
        }

        [TestMethod]
        public void ObtenerInbox_Ok()
        {
            var instancia = new ParametrosInboxDto
                            {
                                Aplicacion = "AP:Backbone",
                                IdUsuario = "jdelgado",
                                IdObjeto = new Guid("bc154cba-50a5-4209-81ce-7c0ff0aec2ce"),
                                ListaIdsRoles =
                                    new List<Guid>()
                                    {
                                        Guid.
                                            Parse("4fe0a3de-0b14-45ed-9137-248bd206a418"),
                                        Guid.
                                            Parse("d76678e3-9264-4663-afe9-7bce43828024"),
                                        Guid.
                                            Parse("1dd225f4-5c34-4c55-b11d-e5856a68839b")
                                    }
                            };

            var actionResult = _inboxController.ObtenerInbox(instancia).Result;
            var contentResult = actionResult as OkNegotiatedContentResult<InboxDto>;

            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual("Prueba Ok", contentResult.Content.Mensaje);
        }
    }
}
