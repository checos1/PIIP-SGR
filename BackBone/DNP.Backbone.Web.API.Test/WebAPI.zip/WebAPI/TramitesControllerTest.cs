﻿namespace DNP.Backbone.Web.API.Test.WebApi
{
    using System.Collections.Generic;
    using System.Web.Http.Results;
    using Controllers;
    using Dominio.Dto;
    using Microsoft.Practices.Unity;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Servicios.Interfaces;

    [TestClass]
    public class TramitesControllerTest
    {
        private IBackboneServicios _backboneServicios;

        private TramitesController _tramitesController;

        [TestInitialize]
        public void Init()
        {
            _backboneServicios = Config.UnityConfig.Container.Resolve<IBackboneServicios>();
            _tramitesController = new TramitesController(_backboneServicios);
        }

        [TestMethod]
        public void CuendoEnvioResponsable_NoRetornaResultados()
        {
            var responsable = "cccccc";

            var actionResult = _tramitesController.ObtenerTramitesPorResponsable(responsable).Result;
            var tramitesPorResponsable = ((OkNegotiatedContentResult<List<SectorDto>>)actionResult).Content;
            Assert.IsTrue(tramitesPorResponsable.Count == 0);
        }

        [TestMethod]
        public void CuendoEnvioResponsable_RetornaResultados()
        {
            var responsable = "jdelgado";

            var actionResult = _tramitesController.ObtenerTramitesPorResponsable(responsable).Result;
            var tramitesPorResponsable = ((OkNegotiatedContentResult<List<SectorDto>>)actionResult).Content;
            Assert.IsTrue(tramitesPorResponsable.Count > 0);
        }

        [TestMethod]
        public void CuandoEnvioParametrosInvalidos_NoRetornaResultados()
        {
            var responsable = "ccccc";
            var numSolicitud = 5;
            var tipoSolicitud = "tipo2";

            var actionResult = _tramitesController.ActualizarPrioridadTramite(numSolicitud, tipoSolicitud, responsable).Result;
            var result = ((OkNegotiatedContentResult<bool>)actionResult).Content;

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CuandoEnvioParametrosValidos_Retornatrue()
        {
            var responsable = "jdelgado";
            var numSolicitud = 1;
            var tipoSolicitud = "tipo1";

            var actionResult = _tramitesController.ActualizarPrioridadTramite(numSolicitud, tipoSolicitud, responsable).Result;
            var result = ((OkNegotiatedContentResult<bool>)actionResult).Content;

            Assert.IsTrue(result);
        }
        
    }
}
